package com.example.clubbola;

public class Menu {
    private String nama;
    private String kota;
    private String gambar;

    public Menu(String datanama,String datakota,String datagambar){
        nama = datanama;
        kota = datakota;
        gambar = datagambar;
    }

    public String getNama() {
        return nama;
    }

    public String getKota() {
        return kota;
    }

    public String getGambar() {
        return gambar;
    }
}
